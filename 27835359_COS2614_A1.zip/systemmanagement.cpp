#include "systemmanagement.h"
#include <QFile>

SystemManagement::SystemManagement() {
    loadFromFile();
}
SystemManagement::~SystemManagement() {
    saveToFile();
    qDeleteAll(vehicle);
}
void SystemManagement::loadFromFile() {
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) return;

    QTextStream stream(&file);
    while (!stream.atEnd()) {
        QString line = stream.readLine().trimmed();
        if (line.isEmpty()) continue;

        QStringList parts = line.split('|');
        if (parts.size() < 6)
            continue;

        QString type = parts[0];
        QString id = parts[1];
        QString brand = parts[2];
        QString model = parts[3];
        double price = parts[4].toDouble();
        bool rented = parts[5] == "1";

        vehicles* v = nullptr;
        if (type == "car" && parts.size()>= 8) {
            v = new cars(id, brand, model, price, parts[6].toInt(), parts[7].toInt());

        }else if (type == "motorcycle" && parts.size() >= 7) {
            v = new motorcycles(id, brand, model, price, parts[6].toInt());

        }
        if (v) {
            v->setIsRented(rented);
            vehicle.append(v);
        }

    }
    file.close();
}
void SystemManagement::saveToFile() {
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        out << "Error: File not saved!!.\n";
        return;
    }
    QTextStream stream(&file);
    for (vehicles* v : vehicle) {
        stream << v->typeName() << "|"
               << v->getId() << "|"
               << v->getBrand() << "|"
               << v->getModel() << "|"
               << v->getDailyPrice() << "|"
               << (v->getIsRented()? "1" : "0");
        if (v->typeName() == "cars") {
            cars* c = static_cast<cars*>(v);
            stream << "|" << c->getnumDoors() << "|" << c->getnumSeats();
        }else if (v->typeName() == "motocycles") {
            motorcycles* m = static_cast<motorcycles*>(v);
            stream << "|" <<m->getEngineSizeES();
        }
        stream << "\n";
    }
    file.close();
}

vehicles* SystemManagement::findVehicles(const QString& id) {
    for (vehicles* v : vehicle) {
        if (v->getId() == id) return v;
    }
        return nullptr;
}

bool SystemManagement::isValidDouble(const QString& input, double& value) {
    bool ok;
    value = input.toDouble(&ok);
    return ok && value >=0;
}
bool SystemManagement::isValidInt(const QString& input, int& value) {
    bool ok;
    value = input.toInt(&ok);
    return ok && value >= 0;
}

void SystemManagement::showMenu() {
    while (true) {
        out <<"========VEHICLE RENTAL MANAGEMENT SYSTEM=========\n"
            << "1. Add vehicle\n"
            << "2. Search vehicle by id\n"
            << "3. Display all vehicles\n"
            << "4. Display available vehicles inly\n"
            << "5. Rent vehicle\n"
            << "6. Return Vehicle\n"
            << "7. Exit\n"
            << "Your selection: ";
        out.flush();

        QString input = in.readLine().trimmed();
        bool ok;
        int option = input.toInt(&ok);
        if (!ok) {
            out << "invalid, enter digit.\n";
            continue;
        }

        switch (option) {
            case 1: addVehicle();
                break;
            case 2: searchVehicle();
                break;
            case 3: displayAll();
                break;
            case 4: displayAvailable();
                break;
            case 5: rentVehicle();
                break;
            case 6: returnVehicle();
                break;
            case 7: return;
            default: out << "wrong option.\n";
        }
    }


}
void SystemManagement::clearInputBuffer() {
    in.readLine();
}
void SystemManagement::addVehicle() {
    out << "car [1] or motorcycle [2]: ";
    QString typeInput = in.readLine().trimmed();
    bool ok;
    int type = typeInput.toInt(&ok);
    if (!ok || (type!= 1 && type!=2)) {
        out << "incorrect type.\n";
        return;
    }
    out << "search by ID: ";
    QString id = in.readLine().trimmed();
    if (id.isEmpty() || findVehicles(id)) {
        out << "error: already exist or ID is empty.\n";
        return;
    }
    out << "enter brand: ";
    QString brand = in.readLine().trimmed();
    out << "enter the model: ";
    QString model = in.readLine().trimmed();

    out << "enter the daily price: ";
    QString priceInput = in.readLine().trimmed();
    double price;
    if (!isValidDouble(priceInput, price)) {
        out << "invalid price.\n";
        return;
    }
    if (type == 1) {
        out << "type the number of doors: ";
        int doors;
        if (!isValidInt(in.readLine().trimmed(), doors)) {
            out <<"invalid number of doors.\n";
            return;
        }
        out << "type number of seats: ";
        int seats;
        if (!isValidInt(in.readLine().trimmed(), seats)) {
            out << "invalid number of seats.\n";
            return;
        }
        vehicle.append(new cars(id, brand, model, price, doors, seats));
    } else {
        out << "enter engine size ES: ";
        int es;
        if (!isValidInt(in.readLine().trimmed(), es)) {
            out << "invalid engine size.\n";
            return;
        }
        vehicle.append(new motorcycles(id, brand, model, price, es));

    }
    out << "successfully added vehicle.\n" ;


}
void SystemManagement::searchVehicle() {
    out << " enter ID: ";
    QString id = in.readLine().trimmed();
    vehicles* v = findVehicles(id);
    out << (v? v->toDisplayString() + "\n" : "unknown vehicle.\n");
}
void SystemManagement::displayAll() {
    if (vehicle.isEmpty()) {
        out << "not in the system.\n";
        return;
    }
    for (vehicles* v : vehicle) {
        out << v->toDisplayString() << "\n";
    }
}
void SystemManagement::displayAvailable() {
    bool found = false;
    for(vehicles* v : vehicle) {
        if (!v->getIsRented()) {
            out << v->toDisplayString() << "\n";
            found = true;
        }
    }
    if (!found)
        out << "not found for rental.\n";
}
void SystemManagement::rentVehicle() {
    out << "enter ID for renting: ";
    QString id = in.readLine().trimmed();
    vehicles* v = findVehicles(id);
    if (!v) {
        out << "vehicle not found.\n";
        return;
    }
    if (v->getIsRented()) {
        out << "already rented.\n";
        return;
    }
    v->setIsRented(true);
    saveToFile();
    out << "successfully rented,\n";
}
void SystemManagement::returnVehicle() {
    out << "enter ID to return: ";
    QString id = in.readLine().trimmed();
    vehicles* v = findVehicles(id);
    if (!v) {
        out << "vehicle not found.\n";
        return;
    }
    if (!v->getIsRented()) {
        out << "vehicle not rented.\n";
        return;
    }
    v->setIsRented(false);
    saveToFile();
    out << " successfully rented vehicle.\n";
}