#include "vehicles.h"

vehicles::vehicles(QString id, QString brand, QString model, double dailyPrice)
    : id(id), brand(brand), model(model), dailyPrice(dailyPrice), isRented(false) {}

QString vehicles::getId() const {return id; }
QString vehicles::getBrand() const {return brand; }
QString vehicles::getModel() const {return model; }
double vehicles::getDailyPrice() const {return dailyPrice; }
bool vehicles::getIsRented() const {return isRented; }


void vehicles::setId(const QString& id) {this->id = id;}
void vehicles::setBrand(const QString& brand) {this->brand = brand;}
void vehicles::setModel(const QString& model) {this->model = model;}
void vehicles::setDailyPrice(double price) {this->dailyPrice = price;}
void vehicles::setIsRented(bool rented) {this->isRented = rented;}

QString vehicles::toDisplayString() const {
    return QString("ID: %1 | %2 %3 | %4/day | result: %5 ")
        .arg(id).arg(brand).arg(model).arg(dailyPrice)
        .arg(isRented? "RENTED" : "AVAILABLE");
}