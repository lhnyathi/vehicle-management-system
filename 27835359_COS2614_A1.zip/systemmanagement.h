#ifndef SYSTEMMANAGEMENT_H
#define SYSTEMMANAGEMENT_H

#include <QVector>
#include <QTextStream>
#include "vehicles.h"
#include "cars.h"
#include "motorcycles.h"

class SystemManagement
{
private:
    QVector<vehicles*> vehicle;
    QTextStream out{stdout};
    QTextStream in{stdin};
    QString filename = "vehicle.txt";

    vehicles* findVehicles(const QString& id);
    bool isValidDouble(const QString& input, double& value);
    bool isValidInt(const QString& input, int& value);
    void clearInputBuffer();

public:
    SystemManagement();
    ~SystemManagement();

    void loadFromFile();
    void saveToFile();
    void showMenu();

    void addVehicle();
    void searchVehicle();
    void displayAll();
    void displayAvailable();
    void rentVehicle();
    void returnVehicle();

};

#endif // SYSTEMMANAGEMENT_H
