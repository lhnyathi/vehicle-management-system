Vehicle Rental Management System - Qt 6


Build Instructions:
1. Install Qt 6 and CMake
2. Open project folder in terminal
3. mkdir build && cd build
4. cmake..
5. cmake --build.

Run:
./car_rental1

Features:
- Add Car or Motorcycle
- Search by ID
- Display all / available vehicles
- Rent and return vehicles
- Data persistence using QFile and QTextStream
- Input validation and error handling

File Format:
type|id|brand|model|price|rented|doors/seats|seats/es
