#include "cars.h"

cars::cars(QString id, QString brand, QString model, double dailyPrice, int doors, int seats)
    : vehicles(id, brand, model, dailyPrice), numDoors(doors), numSeats(seats) {}

QString cars::typeName() const {return "Car"; }

QString cars::toDisplayString() const {
    return vehicles::toDisplayString() +
           QString(" |doors: %1 | Seats: %2").arg(numDoors).arg(numSeats);
}

int cars::getnumDoors() const {return numDoors; }
int cars::getnumSeats() const {return numSeats; }
