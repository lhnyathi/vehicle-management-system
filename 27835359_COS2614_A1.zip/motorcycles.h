#ifndef MOTORCYCLES_H
#define MOTORCYCLES_H

#include "vehicles.h"

class motorcycles : public vehicles
{
private:
    int engineSizeES;

public:
    motorcycles(QString id, QString brand, QString model, double dailyPrice, int ES);

    QString typeName() const override;
    QString toDisplayString() const override;

    int getEngineSizeES() const;
};

#endif // MOTORCYCLES_H
