#ifndef CARS_H
#define CARS_H

#include <vehicles.h>

class cars : public vehicles
{
public:
    cars(QString id, QString brand, QString model, double dailyPrice, int doors, int seats);

    QString typeName() const override;
    QString toDisplayString() const override;

    int getnumDoors() const;
    int getnumSeats() const;
private:
    int numDoors, numSeats;
};

#endif // CARS_H
