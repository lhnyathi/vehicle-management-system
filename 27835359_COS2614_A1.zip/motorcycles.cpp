#include "motorcycles.h"

motorcycles::motorcycles(QString id, QString brand, QString model, double dailyPrice, int ES)
    : vehicles(id, brand, model,dailyPrice), engineSizeES(ES) {}

QString motorcycles::typeName() const {return "Motorcycle"; }

QString motorcycles::toDisplayString() const {
    return vehicles::toDisplayString() +
           QString(" | Engine: %1ES").arg(engineSizeES);
}

int motorcycles::getEngineSizeES() const {return engineSizeES; }
