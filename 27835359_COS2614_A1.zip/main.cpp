#include <QCoreApplication>
#include "systemmanagement.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    SystemManagement management;
    management.showMenu();



    return QCoreApplication::exec();
}
