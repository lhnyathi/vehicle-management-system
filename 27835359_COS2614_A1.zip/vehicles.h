#ifndef VEHICLES_H
#define VEHICLES_H

#include <QString>

class vehicles
{
private:
    QString id;
    QString brand;
    QString model;
    double dailyPrice;
    bool isRented;

public:
    vehicles(QString id, QString brand, QString model, double dailyPrice);
    virtual ~vehicles() = default;

    QString getId() const;
    QString getBrand() const;
    QString getModel() const;
    double getDailyPrice() const;
    bool getIsRented() const;

    void setId(const QString& id);
    void setBrand(const QString& brand);
    void setModel(const QString& model);
    void setDailyPrice(double price);
    void setIsRented(bool rented);

    // pure virtual functions
    virtual QString typeName() const = 0;
    virtual QString toDisplayString() const;
};

#endif // VEHICLES_H
